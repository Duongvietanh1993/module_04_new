create
    definer = root@localhost procedure PROC_SHOW_CATEGORY()
BEGIN
    SELECT * FROM category;
END;

