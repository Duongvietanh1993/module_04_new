create
    definer = root@localhost procedure PROC_UPDATE_PRODUCT(IN id_update int, IN new_name varchar(100),
                                                           IN new_price double, IN new_category_id int)
BEGIN
    UPDATE product
    SET name        = new_name,
        price       = new_price,
        category_id = new_category_id
    WHERE id = id_update;
END;

