create
    definer = root@localhost procedure PROC_SHOW_PRODUCT()
BEGIN
    SELECT * FROM product;
END;

