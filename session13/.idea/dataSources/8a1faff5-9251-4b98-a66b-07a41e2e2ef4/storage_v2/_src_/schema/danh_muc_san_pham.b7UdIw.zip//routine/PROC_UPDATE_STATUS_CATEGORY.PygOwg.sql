create
    definer = root@localhost procedure PROC_UPDATE_STATUS_CATEGORY(IN _id int, IN _status bit)
BEGIN
    UPDATE category SET status=_status WHERE id = _id;
end;

