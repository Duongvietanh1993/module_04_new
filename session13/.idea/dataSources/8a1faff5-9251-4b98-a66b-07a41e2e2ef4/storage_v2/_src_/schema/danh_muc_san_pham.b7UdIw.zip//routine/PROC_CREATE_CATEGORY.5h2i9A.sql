create
    definer = root@localhost procedure PROC_CREATE_CATEGORY(IN new_name varchar(100))
BEGIN
    INSERT INTO category (name) VALUES (new_name);
END;

