create
    definer = root@localhost procedure PROC_FIND_CATEGORY_BY_ID(IN _id int)
BEGIN
    SELECT *FROM category WHERE id = _id;
end;

