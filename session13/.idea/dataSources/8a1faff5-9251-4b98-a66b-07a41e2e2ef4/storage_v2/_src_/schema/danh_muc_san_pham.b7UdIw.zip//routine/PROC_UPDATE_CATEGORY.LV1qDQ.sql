create
    definer = root@localhost procedure PROC_UPDATE_CATEGORY(IN id_update int, IN new_name varchar(100), IN new_status bit)
BEGIN
    UPDATE category
    SET name        = new_name,
        status       = new_status
    WHERE id = id_update;
END;

