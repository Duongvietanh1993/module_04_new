create
    definer = root@localhost procedure PROC_CREATE_PRODUCT(IN new_name varchar(100), IN new_price double, IN new_category_id int)
BEGIN
    INSERT INTO product (name, price, category_id) VALUES (new_name, new_price, new_category_id);
END;

